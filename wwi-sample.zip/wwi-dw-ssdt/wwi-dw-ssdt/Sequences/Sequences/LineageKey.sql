﻿CREATE SEQUENCE [Sequences].[LineageKey]
    AS INT
    START WITH 1
    INCREMENT BY 1;

