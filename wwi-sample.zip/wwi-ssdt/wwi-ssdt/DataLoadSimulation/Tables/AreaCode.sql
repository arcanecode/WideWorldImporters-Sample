﻿CREATE TABLE [DataLoadSimulation].[AreaCode]
(
    StateProvinceCode NVARCHAR(4)
  , AreaCode          NVARCHAR(4)
)
