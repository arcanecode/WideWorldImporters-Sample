﻿CREATE TABLE [DataLoadSimulation].[FicticiousNamePool]
(
    FullName      NVARCHAR(50)
  , PreferredName NVARCHAR(25)
  , LastName      NVARCHAR(25)
  , ToEmail       NVARCHAR(75)
)
