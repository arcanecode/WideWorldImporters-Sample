﻿CREATE ROLE [External Sales]
    AUTHORIZATION [dbo];

