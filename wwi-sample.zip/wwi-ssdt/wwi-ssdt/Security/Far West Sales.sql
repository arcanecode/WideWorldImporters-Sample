﻿CREATE ROLE [Far West Sales]
    AUTHORIZATION [dbo];

