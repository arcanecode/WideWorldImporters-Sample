﻿CREATE ROLE [Southwest Sales]
    AUTHORIZATION [dbo];

