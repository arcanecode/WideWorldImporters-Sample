﻿CREATE SEQUENCE [Sequences].[ColorID]
    AS INT
    START WITH 37
    INCREMENT BY 1;

