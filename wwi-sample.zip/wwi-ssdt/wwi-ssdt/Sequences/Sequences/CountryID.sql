﻿CREATE SEQUENCE [Sequences].[CountryID]
    AS INT
    START WITH 242
    INCREMENT BY 1;

