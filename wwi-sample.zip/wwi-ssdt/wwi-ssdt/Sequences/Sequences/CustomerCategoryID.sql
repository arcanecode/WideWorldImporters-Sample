﻿CREATE SEQUENCE [Sequences].[CustomerCategoryID]
    AS INT
    START WITH 10
    INCREMENT BY 1;



