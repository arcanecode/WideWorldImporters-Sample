﻿CREATE SEQUENCE [Sequences].[CustomerID]
    AS INT
    START WITH 1110
    INCREMENT BY 1;



