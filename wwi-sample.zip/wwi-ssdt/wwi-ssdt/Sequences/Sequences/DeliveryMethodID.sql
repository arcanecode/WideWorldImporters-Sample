﻿CREATE SEQUENCE [Sequences].[DeliveryMethodID]
    AS INT
    START WITH 11
    INCREMENT BY 1;

