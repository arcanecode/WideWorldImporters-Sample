﻿CREATE SEQUENCE [Sequences].[InvoiceID]
    AS INT
    START WITH 149911
    INCREMENT BY 1;



