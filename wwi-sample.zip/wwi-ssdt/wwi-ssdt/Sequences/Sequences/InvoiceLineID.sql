﻿CREATE SEQUENCE [Sequences].[InvoiceLineID]
    AS INT
    START WITH 485930
    INCREMENT BY 1;



