﻿CREATE SEQUENCE [Sequences].[OrderID]
    AS INT
    START WITH 156458
    INCREMENT BY 1;



