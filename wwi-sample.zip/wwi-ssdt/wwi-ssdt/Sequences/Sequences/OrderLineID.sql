﻿CREATE SEQUENCE [Sequences].[OrderLineID]
    AS INT
    START WITH 492602
    INCREMENT BY 1;



