﻿CREATE SEQUENCE [Sequences].[PersonID]
    AS INT
    START WITH 3310
    INCREMENT BY 1;



