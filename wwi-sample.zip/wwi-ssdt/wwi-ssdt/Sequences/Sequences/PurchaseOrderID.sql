﻿CREATE SEQUENCE [Sequences].[PurchaseOrderID]
    AS INT
    START WITH 4427
    INCREMENT BY 1;



