﻿CREATE SEQUENCE [Sequences].[PurchaseOrderLineID]
    AS INT
    START WITH 17086
    INCREMENT BY 1;



