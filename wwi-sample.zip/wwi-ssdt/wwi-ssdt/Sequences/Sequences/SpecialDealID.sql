﻿CREATE SEQUENCE [Sequences].[SpecialDealID]
    AS INT
    START WITH 5
    INCREMENT BY 1;



