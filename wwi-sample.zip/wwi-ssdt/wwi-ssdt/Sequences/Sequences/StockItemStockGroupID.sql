﻿CREATE SEQUENCE [Sequences].[StockItemStockGroupID]
    AS INT
    START WITH 885
    INCREMENT BY 1;



