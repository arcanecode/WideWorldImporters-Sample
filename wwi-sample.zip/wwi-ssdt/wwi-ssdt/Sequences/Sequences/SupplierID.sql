﻿CREATE SEQUENCE [Sequences].[SupplierID]
    AS INT
    START WITH 14
    INCREMENT BY 1;

