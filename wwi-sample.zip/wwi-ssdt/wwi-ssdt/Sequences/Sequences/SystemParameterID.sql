﻿CREATE SEQUENCE [Sequences].[SystemParameterID]
    AS INT
    START WITH 3
    INCREMENT BY 1;



