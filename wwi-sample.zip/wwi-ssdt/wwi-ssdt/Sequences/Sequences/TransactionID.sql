﻿CREATE SEQUENCE [Sequences].[TransactionID]
    AS INT
    START WITH 714101
    INCREMENT BY 1;



