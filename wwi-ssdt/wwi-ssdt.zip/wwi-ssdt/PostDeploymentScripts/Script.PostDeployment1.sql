﻿/*
Post-Deployment Script Template              
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.    
 Use SQLCMD syntax to include a file in the post-deployment script.      
 Example:      :r .\myfile.sql                
 Use SQLCMD syntax to reference a variable in the post-deployment script.    
 Example:      :setvar TableName MyTable              
               SELECT * FROM [$(TableName)]          
--------------------------------------------------------------------------------------
*/


/*GRANT VIEW ANY COLUMN ENCRYPTION KEY DEFINITION TO PUBLIC;


GO
GRANT VIEW ANY COLUMN MASTER KEY DEFINITION TO PUBLIC;
*/

EXEC DataLoadSimulation.DeactivateTemporalTablesBeforeDataLoad;
GO

:r .\pds100-ins-app-people.sql
:r .\pds110-ins-app-countries.sql
:r .\pds120-ins-app-deliverymethods.sql
:r .\pds130-ins-app-paymentmethods.sql
:r .\pds140-ins-app-stateprovinces.sql
:r .\pds142-upd-app-stateprovinces-borders.sql
:r .\pds150-ins-app-cities-a.sql
:r .\pds150-ins-app-cities-b.sql
:r .\pds150-ins-app-cities-c.sql
:r .\pds150-ins-app-cities-d.sql
:r .\pds150-ins-app-cities-e.sql
:r .\pds150-ins-app-cities-f.sql
:r .\pds150-ins-app-cities-g.sql
:r .\pds150-ins-app-cities-h.sql
:r .\pds150-ins-app-cities-i.sql
:r .\pds150-ins-app-cities-j.sql
:r .\pds150-ins-app-cities-k.sql
:r .\pds150-ins-app-cities-l.sql
:r .\pds150-ins-app-cities-m.sql
:r .\pds150-ins-app-cities-n.sql
:r .\pds150-ins-app-cities-o.sql
:r .\pds150-ins-app-cities-p.sql
:r .\pds150-ins-app-cities-q.sql
:r .\pds150-ins-app-cities-r.sql
:r .\pds150-ins-app-cities-s.sql
:r .\pds150-ins-app-cities-t.sql
:r .\pds150-ins-app-cities-u.sql
:r .\pds150-ins-app-cities-v.sql
:r .\pds150-ins-app-cities-w.sql
:r .\pds150-ins-app-cities-x.sql
:r .\pds150-ins-app-cities-y.sql
:r .\pds150-ins-app-cities-z.sql
:r .\pds150-ins-app-cities.sql
:r .\pds160-ins-app-transactiontypes.sql
:r .\pds170-ins-purchasing-suppliercategories.sql
:r .\pds180-ins-sales-groups-categories.sql
:r .\pds190-ins-warehouse-colors.sql
:r .\pds200-ins-warehouse-packagetypes.sql
:r .\pds210-ins-warehouse-stockgroups.sql
:r .\pds220-ins-purchasing-suppliers.sql
:r .\pds230-ins-sales-customers.sql
:r .\pds240-ins-warehouse-stockitems.sql
:r .\pds250-ins-warehouse-stockitemholdings.sql
:r .\pds260-ins-warehouse-stockitemstockgroups.sql
:r .\pds270-ins-app-systemparameters.sql

PRINT 'Data Load Simulation: Reactivate Temporal Tables after Data Load'
GO
EXEC DataLoadSimulation.ReactivateTemporalTablesAfterDataLoad;
GO

PRINT 'Reseed All Sequences'
GO
EXEC Sequences.ReseedAllSequences;
GO

-- To populate the data as part of this uncomment the next section
/*
PRINT 'Populating Data - this may take quite a while so be patient! two to three hours or more is common'
GO

SET NOCOUNT ON;

EXEC DataLoadSimulation.Configuration_ApplyDataLoadSimulationProcedures;
EXEC DataLoadSimulation.DailyProcessToCreateHistory 
    @StartDate = '20130101',
    @EndDate = '20160531',
    @AverageNumberOfCustomerOrdersPerDay = 60,
    @SaturdayPercentageOfNormalWorkDay = 50,
    @SundayPercentageOfNormalWorkDay = 0,
    @UpdateCustomFields = 1,
    @IsSilentMode = 0,
    @AreDatesPrinted = 0;
EXEC DataLoadSimulation.Configuration_RemoveDataLoadSimulationProcedures;
*/

-- To Enable Enterprise features, uncomment this next section
/*
PRINT 'Enabling Enterprise Edition features'
GO

-- Enable Enterprise Edition features (also available in Evaluation/Developer Edition) 
SET NOCOUNT ON;

EXECUTE [Application].Configuration_ConfigureForEnterpriseEdition
GO
*/
