﻿PRINT 'Inserting Application.Cities X'
GO

DECLARE @CurrentDateTime datetime2(7) = '20130101'
DECLARE @EndOfTime datetime2(7) =  '99991231 23:59:59.9999999'

INSERT [Application].Cities (CityID, CityName, StateProvinceID, [Location], LatestRecordedPopulation, LastEditedBy, ValidFrom, ValidTo) 
VALUES (37965, 'Xenia', (SELECT StateProvinceID FROM [Application].StateProvinces WHERE StateProvinceCode = 'KS'), 0xe6100000010cc069b05f66ff42408a462d8320bf57c0, NULL, 1, @CurrentDateTime, @EndOfTime)
     , (37966, 'Xenia', (SELECT StateProvinceID FROM [Application].StateProvinces WHERE StateProvinceCode = 'OH'), 0xe6100000010c04f170f1a6d743400c699e6d7ffb54c0, 25719, 1, @CurrentDateTime, @EndOfTime)
     , (37967, 'Xenia', (SELECT StateProvinceID FROM [Application].StateProvinces WHERE StateProvinceCode = 'IL'), 0xe6100000010cc113c48a64514340a215ce24a02856c0, 391, 1, @CurrentDateTime, @EndOfTime)
GO