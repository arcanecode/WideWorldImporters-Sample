﻿CREATE ROLE [Great Lakes Sales]
    AUTHORIZATION [dbo];

