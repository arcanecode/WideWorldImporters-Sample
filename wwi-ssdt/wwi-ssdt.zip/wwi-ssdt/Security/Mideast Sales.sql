﻿CREATE ROLE [Mideast Sales]
    AUTHORIZATION [dbo];

