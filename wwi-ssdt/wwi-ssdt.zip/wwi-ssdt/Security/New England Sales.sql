﻿CREATE ROLE [New England Sales]
    AUTHORIZATION [dbo];

