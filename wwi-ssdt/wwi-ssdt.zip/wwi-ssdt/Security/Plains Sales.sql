﻿CREATE ROLE [Plains Sales]
    AUTHORIZATION [dbo];

