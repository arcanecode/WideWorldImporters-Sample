﻿CREATE ROLE [Rocky Mountain Sales]
    AUTHORIZATION [dbo];

