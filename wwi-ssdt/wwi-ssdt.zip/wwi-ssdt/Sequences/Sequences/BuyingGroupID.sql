﻿CREATE SEQUENCE [Sequences].[BuyingGroupID]
    AS INT
    START WITH 3
    INCREMENT BY 1;

