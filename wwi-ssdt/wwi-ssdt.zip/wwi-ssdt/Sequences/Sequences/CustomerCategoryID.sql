﻿CREATE SEQUENCE [Sequences].[CustomerCategoryID]
    AS INT
    START WITH 9
    INCREMENT BY 1;

