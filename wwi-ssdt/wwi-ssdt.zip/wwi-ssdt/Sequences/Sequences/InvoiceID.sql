﻿CREATE SEQUENCE [Sequences].[InvoiceID]
    AS INT
    START WITH 78899
    INCREMENT BY 1;

