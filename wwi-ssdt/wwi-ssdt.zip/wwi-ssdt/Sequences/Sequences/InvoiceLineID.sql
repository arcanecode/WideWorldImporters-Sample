﻿CREATE SEQUENCE [Sequences].[InvoiceLineID]
    AS INT
    START WITH 255357
    INCREMENT BY 1;

