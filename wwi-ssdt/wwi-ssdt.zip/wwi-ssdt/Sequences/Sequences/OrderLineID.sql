﻿CREATE SEQUENCE [Sequences].[OrderLineID]
    AS INT
    START WITH 258909
    INCREMENT BY 1;

