﻿CREATE SEQUENCE [Sequences].[PackageTypeID]
    AS INT
    START WITH 15
    INCREMENT BY 1;

