﻿CREATE SEQUENCE [Sequences].[PersonID]
    AS INT
    START WITH 3265
    INCREMENT BY 1;

