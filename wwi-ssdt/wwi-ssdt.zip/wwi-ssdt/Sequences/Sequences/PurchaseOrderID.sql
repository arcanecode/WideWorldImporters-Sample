﻿CREATE SEQUENCE [Sequences].[PurchaseOrderID]
    AS INT
    START WITH 2309
    INCREMENT BY 1;

