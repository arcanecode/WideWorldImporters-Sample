﻿CREATE SEQUENCE [Sequences].[PurchaseOrderLineID]
    AS INT
    START WITH 9302
    INCREMENT BY 1;

