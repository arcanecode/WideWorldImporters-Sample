﻿CREATE SEQUENCE [Sequences].[SpecialDealID]
    AS INT
    START WITH 3
    INCREMENT BY 1;

