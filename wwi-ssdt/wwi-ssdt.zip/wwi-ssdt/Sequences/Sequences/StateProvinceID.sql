﻿CREATE SEQUENCE [Sequences].[StateProvinceID]
    AS INT
    START WITH 54
    INCREMENT BY 1;

