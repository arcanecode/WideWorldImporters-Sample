﻿CREATE SEQUENCE [Sequences].[StockGroupID]
    AS INT
    START WITH 11
    INCREMENT BY 1;

