﻿CREATE SEQUENCE [Sequences].[StockItemID]
    AS INT
    START WITH 228
    INCREMENT BY 1;

