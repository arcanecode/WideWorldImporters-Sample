﻿CREATE SEQUENCE [Sequences].[StockItemStockGroupID]
    AS INT
    START WITH 443
    INCREMENT BY 1;

