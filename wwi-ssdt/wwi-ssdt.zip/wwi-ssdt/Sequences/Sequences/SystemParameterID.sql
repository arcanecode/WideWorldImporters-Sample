﻿CREATE SEQUENCE [Sequences].[SystemParameterID]
    AS INT
    START WITH 2
    INCREMENT BY 1;

