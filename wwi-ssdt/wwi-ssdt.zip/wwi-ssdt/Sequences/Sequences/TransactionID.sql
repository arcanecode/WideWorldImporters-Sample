﻿CREATE SEQUENCE [Sequences].[TransactionID]
    AS INT
    START WITH 376359
    INCREMENT BY 1;

