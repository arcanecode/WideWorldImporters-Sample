﻿CREATE SEQUENCE [Sequences].[TransactionTypeID]
    AS INT
    START WITH 14
    INCREMENT BY 1;

